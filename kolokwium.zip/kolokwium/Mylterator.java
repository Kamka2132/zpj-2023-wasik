package kolokwium;

public interface Mylterator {
    char getNext();

    char getPrevious();

    boolean hasPrevious();

    boolean hasNext();

}
